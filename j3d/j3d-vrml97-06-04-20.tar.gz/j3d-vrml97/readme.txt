J3D-VRML97 loader is released under BSD license. 
Please read LICENSE.TXT to get more detailed information.
